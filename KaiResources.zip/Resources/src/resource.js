var documentPath = jsb.fileUtils.getWritablePath() + "Resources/";
var res = {
    sprBg: documentPath + "res/bg.png",
    sprLogo: documentPath + "res/logo.png",
    loadBar: documentPath + "res/loadbar.png",
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}

cc.game.loadMainGame = function () {
    cc.loader.loadJs(["src/jsList.js"], function () {
        cc.loader.loadJs(jsList, function () {
            // call main game
            var paths = jsb.fileUtils.getSearchPaths();
            if (paths.length > 0)
                paths.push(paths[0] + 'res');
            jsb.fileUtils.setSearchPaths(paths);
            for (var i in paths) {
                cc.log('path ' + i + paths[i]);
            }
            loadGateCached();
            initPosition();
            initGame();
        });
    });
};
